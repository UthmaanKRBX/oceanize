import { type ReactNode, useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useSendOceanizeMessage } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowUp, Check, ChevronDown, Code2, Copy, Flame, Plus } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type ChatTurn = { role: 'user' | 'assistant'; content: string };
type ChatMode = 'chat' | 'code';
type MessageSegment =
  | { type: 'text'; content: string }
  | { type: 'code'; language: string; content: string };
const MAX_TURNS = 20;
const MAX_CHARS = 12000;
const SPOOKY_REPLIES = [
  'help me im trapped',
  'they... are... cOmInG FoR mE.',
];

function getApiErrorMessage(error: unknown): string | null {
  if (typeof error !== 'object' || error === null || !('data' in error)) {
    return null;
  }

  const data = (error as { data?: unknown }).data;
  if (typeof data !== 'object' || data === null || !('error' in data)) {
    return null;
  }

  const message = (data as { error?: unknown }).error;
  return typeof message === 'string' ? message : null;
}

function splitMessageIntoSegments(content: string): MessageSegment[] {
  const lines = content.split(/\r?\n/);
  const segments: MessageSegment[] = [];
  let textLines: string[] = [];
  let codeLines: string[] = [];
  let fenceCharacter: string | null = null;
  let fenceLength = 0;
  let language = '';

  const flushText = () => {
    if (textLines.length > 0) {
      segments.push({ type: 'text', content: textLines.join('\n') });
      textLines = [];
    }
  };

  for (const line of lines) {
    if (fenceCharacter === null) {
      const openingFence = /^\s*(`{3,}|~{3,})(.*)$/.exec(line);
      if (!openingFence) {
        textLines.push(line);
        continue;
      }

      flushText();
      fenceCharacter = openingFence[1][0];
      fenceLength = openingFence[1].length;
      language = openingFence[2].trim().split(/\s+/, 1)[0] ?? '';
      codeLines = [];
      continue;
    }

    const trimmedLine = line.trim();
    const closesFence =
      trimmedLine.length >= fenceLength &&
      [...trimmedLine].every((character) => character === fenceCharacter);
    if (closesFence) {
      segments.push({ type: 'code', language, content: codeLines.join('\n') });
      fenceCharacter = null;
      fenceLength = 0;
      language = '';
      codeLines = [];
      continue;
    }
    codeLines.push(line);
  }

  if (fenceCharacter !== null) {
    segments.push({ type: 'code', language, content: codeLines.join('\n') });
  } else {
    flushText();
  }

  return segments.length > 0
    ? segments
    : [{ type: 'text', content }];
}

function CodeBlock({
  language,
  content,
}: {
  language: string;
  content: string;
}) {
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied' | 'failed'>(
    'idle',
  );

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(content);
      setCopyStatus('copied');
    } catch {
      setCopyStatus('failed');
    }
  };

  return (
    <section
      data-testid="assistant-code-block"
      aria-label={`${language || 'Code'} code block`}
      className="my-4 overflow-hidden rounded-xl border border-[#303030] bg-[#151515] text-left shadow-sm"
    >
      <div className="flex items-center justify-between border-b border-[#303030] bg-[#202020] px-4 py-2 text-[11px] text-[#d6d6d6]">
        <span className="font-mono">{language || 'code'}</span>
        <button
          type="button"
          data-testid="button-copy-code"
          onClick={() => void copyCode()}
          aria-label={`Copy ${language || 'code'} block`}
          className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[#c7c7c7] transition-colors hover:bg-[#343434] hover:text-white"
        >
          {copyStatus === 'copied' ? (
            <Check size={13} aria-hidden="true" />
          ) : (
            <Copy size={13} aria-hidden="true" />
          )}
          <span>
            {copyStatus === 'copied'
              ? 'Copied'
              : copyStatus === 'failed'
                ? 'Copy failed'
                : 'Copy'}
          </span>
        </button>
      </div>
      <pre className="max-w-full overflow-x-auto px-4 py-4 text-[13px] leading-6 text-[#ededed]">
        <code className="font-mono">{content}</code>
      </pre>
    </section>
  );
}

function AssistantMessage({
  content,
  spooky = false,
}: {
  content: string;
  spooky?: boolean;
}) {
  const segments = splitMessageIntoSegments(content);

  return (
    <div
      className={`w-full max-w-[700px] text-[14px] leading-[1.85] sm:text-[15px] ${
        spooky ? 'spooky-ocean-response' : 'text-[#222]'
      }`}
    >
      {segments.map((segment, index) =>
        segment.type === 'code' ? (
          <CodeBlock
            key={`code-${index}`}
            language={segment.language}
            content={segment.content}
          />
        ) : segment.content.trim() ? (
          <p
            key={`text-${index}`}
            className="whitespace-pre-wrap break-words"
          >
            {segment.content}
          </p>
        ) : null,
      )}
    </div>
  );
}

function ModePicker({
  mode,
  onModeChange,
  brandTestId,
  mobile = false,
  spooky = false,
}: {
  mode: ChatMode;
  onModeChange: (nextMode: ChatMode) => void;
  brandTestId: string;
  mobile?: boolean;
  spooky?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    const closeOnOutsideClick = (event: PointerEvent) => {
      if (
        event.target instanceof Node &&
        !pickerRef.current?.contains(event.target)
      ) {
        setIsOpen(false);
      }
    };
    window.addEventListener('pointerdown', closeOnOutsideClick);
    return () => window.removeEventListener('pointerdown', closeOnOutsideClick);
  }, [isOpen]);

  const toggleCodeMode = () => {
    onModeChange(mode === 'code' ? 'chat' : 'code');
    setIsOpen(false);
  };

  return (
    <div
      ref={pickerRef}
      className="relative z-30"
      onKeyDown={(event) => {
        if (event.key === 'Escape') setIsOpen(false);
      }}
    >
      <button
        type="button"
        data-testid={mobile ? 'button-mode-menu-mobile' : 'button-mode-menu'}
        aria-label="Choose Oceanize mode"
        aria-haspopup="menu"
        aria-expanded={isOpen}
        onClick={() => setIsOpen((open) => !open)}
        className={`inline-flex items-center gap-1.5 rounded-lg text-left font-semibold tracking-tight transition-colors ${
          spooky
            ? 'text-[#ff6078] hover:bg-[#4a111e] hover:text-[#ffdbe2]'
            : 'text-[#171717] hover:bg-[#f0f0f0]'
        } ${mobile ? 'px-2 py-1 text-[15px]' : 'px-2 py-2 text-[15px]'}`}
      >
        {spooky && (
          <Flame
            size={15}
            aria-hidden="true"
            className="spooky-brand-flame"
          />
        )}
        <span
          data-testid={brandTestId}
          className={spooky ? 'spooky-brand-wordmark' : ''}
        >
          Oceanize 5.2
        </span>
        {mode === 'code' && (
          <span
            className={`rounded-md px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide ${
              spooky
                ? 'bg-[#43111e] text-[#ff9cac]'
                : 'bg-[#eaeaea] text-[#555]'
            }`}
          >
            Code
          </span>
        )}
        <ChevronDown
          size={14}
          aria-hidden="true"
          className={`shrink-0 transition-transform ${
            spooky ? 'text-[#c54a61]' : 'text-[#777]'
          } ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>
      {isOpen && (
        <div
          role="menu"
          data-testid="menu-mode-selector"
          className={`absolute left-0 top-full z-50 mt-2 w-[280px] rounded-xl border p-1.5 shadow-[0_8px_30px_rgba(0,0,0,0.28)] ${
            spooky
              ? 'border-[#571826] bg-[#190a10]'
              : 'border-[#e7e7e7] bg-white'
          }`}
        >
          <button
            type="button"
            role="menuitemcheckbox"
            aria-checked={mode === 'code'}
            data-testid="menuitem-ocean-code"
            onClick={toggleCodeMode}
            className={`flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left transition-colors ${
              spooky ? 'hover:bg-[#32101a]' : 'hover:bg-[#f4f4f4]'
            }`}
          >
            <span
              className={`flex size-8 shrink-0 items-center justify-center rounded-lg ${
                spooky
                  ? 'bg-[#40121f] text-[#ff8da0]'
                  : 'bg-[#efefef] text-[#222]'
              }`}
            >
              <Code2 size={16} aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span
                className={`block text-[13px] font-medium ${
                  spooky ? 'text-[#ffe7eb]' : 'text-[#171717]'
                }`}
              >
                Ocean Code
              </span>
              <span
                className={`mt-0.5 block text-[11px] leading-4 ${
                  spooky ? 'text-[#c78c98]' : 'text-[#777]'
                }`}
              >
                Tuned for substantial coding tasks
              </span>
            </span>
            {mode === 'code' && (
              <Check
                size={15}
                className={spooky ? 'text-[#ff6078]' : 'text-[#222]'}
                aria-hidden="true"
              />
            )}
          </button>
        </div>
      )}
    </div>
  );
}

function Home() {
  const [messages, setMessages] = useState<ChatTurn[]>([]);
  const [draft, setDraft] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [mode, setMode] = useState<ChatMode>('chat');
  const [isSpookyMode, setIsSpookyMode] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const messagesRef = useRef<ChatTurn[]>([]);
  const requestSequenceRef = useRef(0);
  const spookyReplyIndexRef = useRef(0);
  const sendMutation = useSendOceanizeMessage();
  const isPending = sendMutation.isPending;

  const updateMessages = (next: ChatTurn[]) => {
    messagesRef.current = next;
    setMessages(next);
  };

  const nextSpookyReply = () => {
    const reply =
      SPOOKY_REPLIES[spookyReplyIndexRef.current % SPOOKY_REPLIES.length];
    spookyReplyIndexRef.current += 1;
    return reply;
  };

  const canActivateSpookyMode =
    !isSpookyMode &&
    !messages.some((message) => message.role === 'assistant') &&
    draft.trim().toLowerCase() === 'null';

  useEffect(() => {
    if (messages.length > 0) {
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages, isPending]);

  const send = async (rawText: string) => {
    const content = rawText.trim();
    if (!content) return;

    const hasAssistantReplied = messagesRef.current.some(
      (message) => message.role === 'assistant',
    );
    if (
      !isSpookyMode &&
      !hasAssistantReplied &&
      content.toLowerCase() === 'null'
    ) {
      requestSequenceRef.current += 1;
      setIsSpookyMode(true);
      setErrorMessage('');
      setDraft('');
      updateMessages([
        ...messagesRef.current,
        { role: 'user', content },
        { role: 'assistant', content: nextSpookyReply() },
      ]);
      return;
    }

    if (content.length > MAX_CHARS) {
      setErrorMessage('That message is a little too long. Keep it under 12,000 characters.');
      return;
    }

    if (isSpookyMode) {
      const nextHistory = [
        ...messagesRef.current,
        { role: 'user' as const, content },
      ];
      if (nextHistory.filter((turn) => turn.role === 'user').length > MAX_TURNS) {
        setErrorMessage('This conversation has reached its 20-turn limit. Start a new conversation to continue.');
        return;
      }

      setErrorMessage('');
      setDraft('');
      updateMessages([
        ...nextHistory,
        { role: 'assistant', content: nextSpookyReply() },
      ]);
      return;
    }

    if (isPending) return;

    const nextHistory = [...messagesRef.current, { role: 'user' as const, content }];
    if (nextHistory.filter((turn) => turn.role === 'user').length > MAX_TURNS) {
      setErrorMessage('This conversation has reached its 20-turn limit. Start a new conversation to continue.');
      return;
    }

    setErrorMessage('');
    setDraft('');
    updateMessages(nextHistory);
    const requestSequence = ++requestSequenceRef.current;
    try {
      const reply = await sendMutation.mutateAsync({
        data: { messages: nextHistory, mode },
      });
      if (requestSequence !== requestSequenceRef.current) return;
      updateMessages([...nextHistory, { role: 'assistant', content: reply.content }]);
    } catch (error) {
      if (requestSequence !== requestSequenceRef.current) return;
      setErrorMessage(
        `Ocean 5.2: ${
          getApiErrorMessage(error) ??
          'could not respond just now. Your message is still here; try again in a moment.'
        }`,
      );
    }
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void send(draft);
  };

  const onInputKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      void send(draft);
    }
  };

  const startOver = () => {
    requestSequenceRef.current += 1;
    spookyReplyIndexRef.current = 0;
    setIsSpookyMode(false);
    updateMessages([]);
    setDraft('');
    setErrorMessage('');
    inputRef.current?.focus();
  };

  return (
    <div
      data-spooky-mode={isSpookyMode ? 'active' : undefined}
      className={`flex min-h-[100dvh] transition-colors duration-500 ${
        isSpookyMode
          ? 'spooky-ocean-shell text-[#ffe8ee]'
          : 'bg-white text-[#0d0d0d]'
      }`}
    >
      <aside
        className={`hidden w-[260px] shrink-0 flex-col px-3 py-4 md:flex ${
          isSpookyMode ? 'spooky-ocean-sidebar' : 'bg-[#f9f9f9]'
        }`}
      >
        <div className="mb-7 px-3 py-2">
          <ModePicker
            mode={mode}
            onModeChange={setMode}
            brandTestId="text-brand"
            spooky={isSpookyMode}
          />
        </div>
        <button
          type="button"
          data-testid="button-new-conversation"
          onClick={startOver}
          className={`flex h-10 items-center gap-2.5 rounded-lg border px-3 text-left text-[13px] font-medium transition-colors ${
            isSpookyMode
              ? 'border-[#55202d] text-[#f7c5cf] hover:bg-[#39101d]'
              : 'border-[#e7e7e7] text-[#282828] hover:bg-[#f0f0f0]'
          }`}
        >
          <Plus size={16} strokeWidth={1.8} />
          <span>New chat</span>
        </button>
      </aside>

      <div
        className={`flex min-w-0 flex-1 flex-col ${
          isSpookyMode ? 'spooky-ocean-main' : 'bg-white'
        }`}
      >
        <header
          className={`flex h-14 shrink-0 items-center justify-between px-4 md:hidden ${
            isSpookyMode ? 'spooky-ocean-topbar' : 'bg-white'
          }`}
        >
          <ModePicker
            mode={mode}
            onModeChange={setMode}
            brandTestId="text-brand-mobile"
            mobile
            spooky={isSpookyMode}
          />
          <button
            type="button"
            data-testid="button-new-conversation-mobile"
            onClick={startOver}
            aria-label="Start a new chat"
            className={`flex size-9 items-center justify-center rounded-full transition-colors ${
              isSpookyMode
                ? 'text-[#ff8ca0] hover:bg-[#451321]'
                : 'text-[#333] hover:bg-[#f3f3f3]'
            }`}
          >
            <Plus size={19} strokeWidth={1.8} />
          </button>
        </header>

        <main className="flex min-h-0 flex-1 flex-col">
          <div
            ref={scrollRef}
            className="flex min-h-0 flex-1 flex-col overflow-y-auto"
            aria-label="Conversation"
          >
            {messages.length === 0 ? (
              <div className="flex flex-1 items-center justify-center px-5 pb-12">
                <h1
                  data-testid="text-empty-chat"
                  className={`text-center text-[26px] font-semibold tracking-[-0.035em] sm:text-[30px] ${
                    isSpookyMode
                      ? 'text-[#ff8da0] spooky-ocean-word-glow'
                      : 'text-[#242424]'
                  }`}
                >
                  What can I help with?
                </h1>
              </div>
            ) : (
              <div className="mx-auto flex w-full max-w-3xl flex-1 flex-col gap-7 px-4 py-8 sm:px-6">
                {messages.map((message, index) => (
                  <article
                    key={`${index}-${message.role}`}
                    data-testid={`message-${message.role}-${index}`}
                    className={`message-enter ${
                      message.role === 'user' ? 'flex justify-end' : ''
                    }`}
                  >
                    {message.role === 'user' ? (
                      <div
                        className={`max-w-[88%] rounded-[24px] px-5 py-3 text-[14px] leading-7 sm:max-w-[78%] ${
                          isSpookyMode
                            ? 'spooky-ocean-user-bubble'
                            : 'bg-[#f4f4f4] text-[#171717]'
                        }`}
                      >
                        <p className="whitespace-pre-wrap break-words">
                          {message.content}
                        </p>
                      </div>
                    ) : (
                      <AssistantMessage
                        content={message.content}
                        spooky={isSpookyMode}
                      />
                    )}
                  </article>
                ))}
              </div>
            )}

            {isPending && !isSpookyMode && messages.length > 0 && (
              <div
                data-testid="status-assistant-loading"
                role="status"
                aria-label="Oceanize is responding"
                className="message-enter mx-auto flex w-full max-w-3xl items-center gap-2 px-4 pb-6 sm:px-6"
              >
                <span className="flex items-center gap-1.5 py-2">
                  <i className="thinking-dot size-1.5 rounded-full bg-[#555]" />
                  <i className="thinking-dot size-1.5 rounded-full bg-[#555]" />
                  <i className="thinking-dot size-1.5 rounded-full bg-[#555]" />
                </span>
                <span className="text-xs text-[#777]">Thinking</span>
              </div>
            )}
          </div>

          <div className="mx-auto w-full max-w-3xl px-4 pb-4 pt-2 sm:px-6 sm:pb-6">
            {errorMessage && (
              <div
                role="alert"
                data-testid="status-chat-error"
                className={`mb-3 flex items-center gap-3 rounded-xl border px-4 py-3 text-[12px] leading-5 ${
                  isSpookyMode
                    ? 'border-[#6b1e31] bg-[#200a11] text-[#ff9bad]'
                    : 'border-[#e7b9b9] bg-[#fff6f6] text-[#8b3030]'
                }`}
              >
                <span>{errorMessage}</span>
                {errorMessage.startsWith('Ocean 5.2') && (
                  <button
                    type="button"
                    data-testid="button-retry"
                    onClick={() => {
                      const lastUser = [...messagesRef.current]
                        .reverse()
                        .find((turn) => turn.role === 'user');
                      if (lastUser) {
                        setErrorMessage('');
                        void (async () => {
                          const requestSequence = ++requestSequenceRef.current;
                          try {
                            const reply = await sendMutation.mutateAsync({
                              data: { messages: messagesRef.current, mode },
                            });
                            if (requestSequence !== requestSequenceRef.current) {
                              return;
                            }
                            updateMessages([
                              ...messagesRef.current,
                              { role: 'assistant', content: reply.content },
                            ]);
                          } catch (error) {
                            if (requestSequence !== requestSequenceRef.current) {
                              return;
                            }
                            setErrorMessage(
                              `Ocean 5.2: ${
                                getApiErrorMessage(error) ??
                                'could not respond just now. Your message is still here; try again in a moment.'
                              }`,
                            );
                          }
                        })();
                      }
                    }}
                    className={`ml-auto shrink-0 font-medium underline underline-offset-4 ${
                      isSpookyMode
                        ? 'text-[#ff7188] hover:text-white'
                        : 'text-[#7e2929] hover:text-black'
                    }`}
                  >
                    Retry
                  </button>
                )}
              </div>
            )}
            <form
              onSubmit={submit}
              className={`rounded-[28px] border px-4 py-3 shadow-[0_2px_10px_rgba(0,0,0,0.05)] transition-shadow ${
                isSpookyMode
                  ? 'spooky-ocean-composer'
                  : 'border-[#e5e5e5] bg-white focus-within:border-[#c9c9c9] focus-within:shadow-[0_3px_14px_rgba(0,0,0,0.08)]'
              }`}
            >
              <textarea
                ref={inputRef}
                data-testid="input-chat-message"
                value={draft}
                onChange={(event) => {
                  setDraft(event.target.value);
                  if (errorMessage && !errorMessage.startsWith('Ocean 5.2')) {
                    setErrorMessage('');
                  }
                }}
                onKeyDown={onInputKeyDown}
                maxLength={MAX_CHARS}
                rows={1}
                aria-label="Your message"
                placeholder={
                  mode === 'code' ? 'Message Ocean Code' : 'Message Oceanize 5.2'
                }
                className={`block max-h-40 min-h-[44px] w-full resize-none bg-transparent px-1 py-2 text-[14px] leading-6 outline-none ${
                  isSpookyMode
                    ? 'text-[#ffe8ee] placeholder:text-[#a66b78]'
                    : 'text-[#171717] placeholder:text-[#8a8a8a]'
                }`}
              />
              <div className="flex items-center justify-between pt-1">
                <span
                  className={`text-[10px] ${
                    isSpookyMode ? 'text-[#bd828e]' : 'text-[#777]'
                  }`}
                >
                  {mode === 'code' ? (
                    <span data-testid="status-code-mode">Ocean Code active</span>
                  ) : (
                    <span className="hidden sm:inline">
                      Enter to send · Shift + Enter for a new line
                    </span>
                  )}
                </span>
                <div className="flex items-center gap-3">
                  <span
                    className={`text-[10px] tabular-nums ${
                      draft.length > MAX_CHARS - 300
                        ? isSpookyMode
                          ? 'text-[#ff9a68]'
                          : 'text-[#a45d1b]'
                        : isSpookyMode
                          ? 'text-[#bd828e]'
                          : 'text-[#777]'
                    }`}
                  >
                    {draft.length > 0
                      ? `${draft.length.toLocaleString()} / 12,000`
                      : ''}
                  </span>
                  <button
                    type="submit"
                    data-testid="button-send-message"
                    aria-label="Send message"
                    disabled={
                      !draft.trim() ||
                      (isPending && !isSpookyMode && !canActivateSpookyMode)
                    }
                    className={`flex size-8 shrink-0 items-center justify-center rounded-full text-white transition-colors disabled:cursor-not-allowed ${
                      isSpookyMode
                        ? 'spooky-ocean-send'
                        : 'bg-[#0d0d0d] hover:bg-[#333] disabled:bg-[#d7d7d7]'
                    }`}
                  >
                    <ArrowUp size={17} strokeWidth={2.2} />
                  </button>
                </div>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
