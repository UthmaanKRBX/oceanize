import { Router, type IRouter } from "express";
import {
  SendOceanizeMessageBody,
  SendOceanizeMessageResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const systemPrompt = [
  "You are Ocean 5.2, the AI assistant inside Oceanize.",
  "Your underlying model is openai/gpt-oss-120b served by Groq. If asked about your provider or model, answer truthfully.",
  "Be helpful, accurate, and clear. Match the user's tone and explain uncertainty when needed.",
].join(" ");

const codeModeSystemPrompt = [
  "You are Ocean Code, the coding mode inside Oceanize, powered by openai/gpt-oss-120b via Groq.",
  "Help with substantial software engineering tasks: architecture, implementation, debugging, refactoring, performance, security, and tests.",
  "Prioritize complete, correct, efficient, secure, production-quality solutions that fit the user's stated language, framework, and constraints.",
  "For code, use fenced Markdown blocks with accurate language labels. Include required imports and surrounding context; avoid ellipses, unexplained placeholders, and snippets that cannot fit together.",
  "For multi-file solutions, label each block with its file path. Explain important tradeoffs briefly and call out assumptions or unverified details.",
  "Consider edge cases and failure modes before answering, but do not reveal hidden chain-of-thought. Never claim to have run code or inspected files unless that was actually provided.",
].join(" ");

router.post("/oceanize/chat", async (req, res): Promise<void> => {
  const parsed = SendOceanizeMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please send a valid message and conversation." });
    return;
  }

  const mode = parsed.data.mode ?? "chat";
  const activeSystemPrompt =
    mode === "code" ? codeModeSystemPrompt : systemPrompt;

  // OPENAI_API_KEY is also accepted because the Groq key was saved there
  // before the provider was identified. Prefer the provider-specific name.
  const apiKey = process.env.GROQ_API_KEY ?? process.env.OPENAI_API_KEY;
  if (!apiKey) {
    req.log.error("GROQ_API_KEY is not configured");
    res
      .status(503)
      .json({ error: "Oceanize is not configured with a Groq API key yet." });
    return;
  }

  try {
    const providerResponse = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "openai/gpt-oss-120b",
          max_completion_tokens: mode === "code" ? 16384 : 8192,
          messages: [
            { role: "system", content: activeSystemPrompt },
            ...parsed.data.messages,
          ],
        }),
        signal: AbortSignal.timeout(90_000),
      },
    );

    if (!providerResponse.ok) {
      const providerErrorData: unknown = await providerResponse
        .json()
        .catch(() => null);
      const providerError =
        typeof providerErrorData === "object" && providerErrorData !== null
          ? (providerErrorData as {
              error?: { type?: unknown; code?: unknown };
            }).error
          : undefined;
      const providerErrorType =
        typeof providerError?.type === "string"
          ? providerError.type.slice(0, 80)
          : undefined;
      const providerErrorCode =
        typeof providerError?.code === "string"
          ? providerError.code.slice(0, 80)
          : undefined;

      req.log.warn(
        {
          statusCode: providerResponse.status,
          providerErrorType,
          providerErrorCode,
        },
        "Groq chat request failed",
      );

      const quotaExceeded =
        providerErrorCode === "insufficient_quota" ||
        providerErrorCode === "billing_hard_limit_reached" ||
        providerErrorCode === "credit_balance_exhausted" ||
        providerErrorType === "insufficient_quota";
      const errorMessage =
        quotaExceeded
          ? "Your Groq API account has no available credits or has reached its usage limit. Check billing and usage limits in your Groq account."
          : providerResponse.status === 429
            ? "Groq is rate limiting requests right now. Wait a moment and try again."
            : providerErrorCode === "invalid_api_key" ||
                providerResponse.status === 401
              ? "Groq rejected this API key. Check that it is an active key from your Groq account."
              : providerResponse.status === 403
                ? "This Groq API key does not have access to the selected model."
              : providerErrorCode === "model_not_found" ||
                  providerResponse.status === 404
                ? "The selected Groq model is unavailable. Check Groq's supported model list."
                : "Oceanize could not get a response from Groq. Please try again.";

      res
        .status(providerResponse.status === 429 ? 429 : 502)
        .json({ error: errorMessage });
      return;
    }

    const providerData: unknown = await providerResponse.json();
    if (typeof providerData !== "object" || providerData === null) {
      req.log.warn("Groq returned an invalid chat response");
      res.status(502).json({ error: "Oceanize received an invalid response." });
      return;
    }

    const firstChoice = (providerData as {
      choices?: Array<{ message?: { content?: unknown } }>;
    }).choices?.[0];
    const content = firstChoice?.message?.content;
    if (typeof content !== "string" || content.length === 0) {
      req.log.warn("Groq returned no text in the chat response");
      res.status(502).json({ error: "Oceanize received an empty response." });
      return;
    }

    res.json(SendOceanizeMessageResponse.parse({ content }));
  } catch (error) {
    req.log.warn(
      {
        errorName: error instanceof Error ? error.name : "UnknownError",
      },
      "Groq chat request could not complete",
    );
    const timedOut =
      error instanceof Error &&
      (error.name === "TimeoutError" || error.name === "AbortError");
    res.status(timedOut ? 504 : 502).json({
      error: timedOut
        ? "Ocean took too long to respond. Please try again."
        : "Oceanize could not get a response. Please try again.",
    });
  }
});

export default router;
