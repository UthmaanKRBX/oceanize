import { Router, type IRouter } from "express";
import healthRouter from "./health";
import oceanizeRouter from "./oceanize";

const router: IRouter = Router();

router.use(healthRouter);
router.use(oceanizeRouter);

export default router;
